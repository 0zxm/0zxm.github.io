## Objective

**In this lab, you need to modify some files in the `linux/kernel/chr_drv` directory so that after the `F12` key is pressed, all letters output to the monitor are displayed as \"\*\*\*\", and when the user presses `F12` again, the display returns to normal.**

## Demo

![demo](./img/demo.gif)

