

# password = input('请输入您的银行卡密码')
# print('我的密码是:%s' % password)

name = input('请输入您的名字')
print('我的名字是:%s' % name)

