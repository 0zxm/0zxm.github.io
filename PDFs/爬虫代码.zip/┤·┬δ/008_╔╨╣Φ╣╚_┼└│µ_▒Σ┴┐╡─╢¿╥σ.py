# ctrl + ？
# 重复的值 书写/修改起来都很麻烦

# 在不使用变量的情况下
print('今天的天气很好，晴天了')
print('今天的天气很好，晴天了')
print('今天的天气很好，晴天了')
print('今天的天气很好，晴天了')


# 在使用变量的情况下
# 变量的格式： 变量的名字 = 变量的值

weather = '今天的天气很好，晴天了1111'

print(weather)
print(weather)
print(weather)
print(weather)

# 应用场景
img = 'https://item.jd.com/10027680626445.html'
print(img)
