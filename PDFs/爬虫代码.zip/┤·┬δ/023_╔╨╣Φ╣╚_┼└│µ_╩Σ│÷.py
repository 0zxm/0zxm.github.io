

# 普通输出
print('故事里的小黄花，从出生那年就飘着')

# 格式化输出
# scrapy框架的时候   excel文件  mysql  redis
age = 18
name = '红浪漫晶哥'

# %s 代表的是字符串    %d 代表的是数值
print('我的名字是%s,我的年龄是%d' % (name,age))