# ifelse的语法
# if 判断条件:
#       判断条件为true的时候执行的代码
# else:
#       判断条件为false的时候执行的代码


age = 17

if age > 18:
    print('你可以去网吧了')
else:
    print('回家写作业去吧')
