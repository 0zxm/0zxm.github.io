# list  列表
# tuple 元组
# dict  字典


# list  列表
# 应用场景：当获取到了很多个数据的时候 那么我们可以将他们存储到列表中 然后直接使用列表访问
name_list = ['周杰伦','科比']
print(name_list)

# tuple 元组
age_tuple = (18,19,20,21)
print(age_tuple)

# dict  字典
# 应用场景：scrapy框架使用
# 格式：变量的名字 = {key:value,key1:value1}
person = {'name':'红浪漫','age':18}
print(person)

# 要求必须掌握 列表 元组  字典的格式