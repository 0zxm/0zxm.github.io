

person = {'name':'张三','age':18}


# 修改之前的字典
print(person)

# 修改name的值为法外狂徒
person['name'] = '法外狂徒'

# 修改之后的字典
print(person)