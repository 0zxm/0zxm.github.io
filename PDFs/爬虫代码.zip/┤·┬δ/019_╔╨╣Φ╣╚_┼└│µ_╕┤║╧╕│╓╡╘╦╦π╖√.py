a = 1
# a加上一个2 打印结果
# a = a + 2
# print(a)

a += 2   # a = a + 2
print(a)

b = 1
# b 乘以一个3 打印结果
# b = b * 3
# print(b)

b *= 3  # b = b * 3
print(b)

c = 2
# c 减去一个1 打印结果
# c = c - 1
# print(c)

c -= 1  # c = c - 1
print(c)


d = 3

# d 除以一个2 打印结果
# d = d / 2
# print(d)

d /= 2 # d = d / 2
print(d)

e = 3

# e 整除一个2 打印结果
# e = e // 2
# print(e)

e //= 2  # e = e // 2
print(e)

# %  取余  取模  模余
f = 3
# f 对5来取余数 打印结果
# f = f % 5
# print(f)

f %= 5 # f = f % 5
print(f)


g = 5

# 求一下5的3次幂
# g = g ** 3
# print(g)

g **= 3   # g = g ** 3
print(g)

# +=  -+  *=  /=  //=  %=  **=