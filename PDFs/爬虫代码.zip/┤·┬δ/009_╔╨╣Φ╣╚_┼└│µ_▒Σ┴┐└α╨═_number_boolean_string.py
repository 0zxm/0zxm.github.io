# 数据类型
# Number     数值
#      int
#      float
# boolean    布尔
# string     字符串
# list       列表
# tuple      元组
# dict       字典

# 变量类型的基本使用
# Number     数值
#      int
money = 5000
#      float
money1 = 1.2

# boolean    布尔
# 流程控制语句
# 性别的变量
# 性别在实际的企业级开发中 使用的单词是sex  gender
# 男  True
sex = True
gender = False

# string     字符串
# 字符串 使用的是单引号 或者双引号
s = '苍茫的大海上有一只海燕 你可长点心吧'
s1 = "嘀嗒嘀嗒嘀"
# 不允许一单一双 屌丝写法
# s2 = '哈哈哈"
# s3 = "呵呵呵'

# 单引号和双引号的嵌套
s4 = '"嘿嘿嘿"'
print(s4)
s5 = "'嘿嘿'"
print(s5)

# 单引号套单引号  双引号套双引号
# s6 = ''行还是不行呢''
# s7 = ""行还是不行呢""









