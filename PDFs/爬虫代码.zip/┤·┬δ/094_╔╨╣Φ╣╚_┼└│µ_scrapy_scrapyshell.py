# 进入到scrapy shell的终端  直接在window的终端中输入scrapy shell 域名
# 如果想看到一些高亮 或者 自动补全  那么可以安装ipython  pip install ipython


# scrapy shell www.baidu.com