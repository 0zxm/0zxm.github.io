

# 返回值的关键字是return，存在函数中

# def buyIceCream():
#
#     return '冰激凌'
#
# # 使用一个变量来接受函数的返回值
# food = buyIceCream()
#
# print(food)

# 案例练习
# 定义一个函数 然后让函数计算两个数值的和  并且返回这个计算之后的结果

def sum(a,b):
    c = a + b
    return c

a = sum(123,456)

print(a)
