a = 10
print(a)


b = c = 20
print(b)
print(c)

# 多个变量赋值(使用逗号分隔)
d,e,f = 1,2,3
print(d)
print(e)
print(f)

