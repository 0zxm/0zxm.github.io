
# append  追加   在列表的最后来添加一个对象/数据
food_list = ['铁锅炖大鹅','酸菜五花肉']
print(food_list)

food_list.append('小鸡炖蘑菇')
print(food_list)


# insert  插入
char_list = ['a','c','d']
print(char_list)
# index的值就是你想插入数据的那个下标
char_list.insert(1,'b')
print(char_list)


# extend
num_list = [1,2,3]
num1_list = [4,5,6]

num_list.extend(num1_list)
print(num_list)



