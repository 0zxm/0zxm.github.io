

# in 是判断某一个元素是否在某一个列表中
# food_list = ['锅包肉','汆白肉','东北乱炖']

# 判断一下在控制台输入的那个数据 是否在列表中
# food = input('请输入您想吃的食物')
#
# if food in food_list:
#     print('在')
# else:
#     print('不在，一边拉去')


# not in

ball_list = ['篮球','台球']

# 在控制台上输入你喜欢的球类 然后判断是否不在这个列表中
ball = input('请输入您喜欢的球类')

if ball not in ball_list:
    print('不在')
else:
    print('在')